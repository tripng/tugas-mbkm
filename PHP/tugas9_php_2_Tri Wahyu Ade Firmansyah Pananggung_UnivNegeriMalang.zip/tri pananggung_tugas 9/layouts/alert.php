<div class="alert">
    <div class="info">
        <h1>ERROR URL</h1>
        <p>Maaf URL Tidak Ditemukan</p>
        <button onclick=history.go(-1);>X</button>
    </div>
</div>