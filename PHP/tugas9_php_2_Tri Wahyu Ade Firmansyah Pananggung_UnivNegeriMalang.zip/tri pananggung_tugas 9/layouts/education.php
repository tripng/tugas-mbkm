<table class="table text-dark table-hover fs-5" border="1" style="width:75%;margin:50px auto;">
    <thead>
        <tr>
            <th scope="col"></th>
            <th scope="col">Tingkat</th>
            <th scope="col">Pendidikan</th>
            <th scope="col">Tahun</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <th scope="row">1</th>
            <td>Sekolah Dasar</td>
            <td>Madrasah Ibtidaiya Kota Utara</td>
            <td>2007 - 2013</td>
        </tr>
        <tr>
            <th scope="row">2</th>
            <td>Sekolah Menengah Pertama</td>
            <td>Madrasah Tsanawiyah Negeri Gorontalo</td>
            <td>2013 - 2016</td>
        </tr>
        <tr>
            <th scope="row">3</th>
            <td>Sekolah Menengah Atas</td>
            <td>Madrasah Aliyah Negeri Model Gorontalo</td>
            <td>2016 - 2019</td>
        </tr>
        <tr>
            <th scope="row">4</th>
            <td>Kuliah</td>
            <td>Universitas Negeri Malang</td>
            <td>2019 - Sekarang</td>
        </tr>
    </tbody>
</table>