<!-- Header -->
<header id="header">
    <h1>TRIPANANGGUNG</h1>
    <nav>
        <ul>
            <li>
                <div class="dropdown">
                    My Self <span>∇</span>
                    <div class="dropdown-content">
                        <a href="?hal=home">Home</a>
                        <a href="?hal=home#one">About Me</a>
                        <a href="?hal=home#two">Cooperation</a>
                    </div>
                </div>
            </li>
            <li><a href="?hal=education">Education</a></li>
            <li><a href="?hal=gallery">Gallery</a></li>
            <li><a href="?hal=contact">Contact</a></li>
        </ul>
    </nav>
</header>