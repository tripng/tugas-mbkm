    <!-- Intro -->
    <section id="intro" class="main style1 dark fullscreen">
        <div class="content">
            <header>
                <h2>Tri Pananggung.</h2>
            </header>
            <p>Hi, <strong>Selamat Datang</strong> namaku Tri seorang pelajar di Universitas Negeri Malang jurusan
                Teknik Informatika</p>
            <footer>
                <a href="#one" class="button style2 down">Lebih Lanjut</a>
            </footer>
        </div>
    </section>

    <!-- One -->
    <section id="one" class="main style2 right dark fullscreen">
        <div class="content box style2">
            <header>
                <h2>About Me</h2>
            </header>
            <p>Haii.. Namaku Tri Wahyu Ade Firmansyah Pananggung aku adalah
                seorang mahasiswa dari Universitas Negeri Malang jurusan Teknik Informatika. aku memiliki ketertarikan
                pada
                web
                development, game development, dan designer. aku berasal dari Gorontalo dan memiliki umur 19 tahun.</p>
        </div>
        <a href="#two" class="button style2 down anchored">Next</a>
    </section>

    <!-- Two -->
    <section id="two" class="main style2 left dark fullscreen">
        <div class="content box style2">
            <header>
                <h2>Cooperation</h2>
            </header>
            <p>Aku dapat melakukan pekerjaan dalam mendevelop website, game, apk mobile, dan juga dapat melakukan
                pekerjaan
                seperti design grafis, video editing, beserta 3D model dan lain sebagainya. Jika anda memiliki
                pertanyaan atau tertarik bekerja sama denganku silahkan ke bagian kontak atau menghubungi
                pada media sosial yang telah diberikan.</p>
        </div>
        <a href="#work" class="button style2 down anchored">Next</a>
    </section>